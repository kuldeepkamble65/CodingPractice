package BankApplication;

public class CarLoan extends Loan{
    public CarLoan(double loanAmount) {
        super(loanAmount, 6.0);
    }
}
