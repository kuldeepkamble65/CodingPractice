package BankApplication;

public class PersonalLoan extends Loan{
    public PersonalLoan(double loanAmount) {
        super(loanAmount, 5.0);
    }
}
