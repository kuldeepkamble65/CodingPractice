package Assi3_TravelBook;

public class Train extends TravelMode {
    public Train(String source, String destination, String arrivalTime, String departureTime) {
        super(source, destination, arrivalTime, departureTime);
    }
}
