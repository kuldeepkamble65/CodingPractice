package Assi3_TravelBook;

public class Bus extends TravelMode{
    public Bus(String source, String destination, String arrivalTime, String departureTime) {
        super(source, destination, arrivalTime, departureTime);
    }
}
